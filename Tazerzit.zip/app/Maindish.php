<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Maindish extends Model
{
    protected $table="maindishs" ;
    protected $guarded=[];
    //
}
