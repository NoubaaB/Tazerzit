/*global $ , alert, console*/
    $(function () {
      'use strict';
      $("html").niceScroll();
    });
    
    $('.header').height($(window).height());
