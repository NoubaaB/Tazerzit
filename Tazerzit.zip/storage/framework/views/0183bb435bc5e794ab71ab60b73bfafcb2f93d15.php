<?php $__env->startSection('title',"Page Not Found | 404"); ?>
<?php $__env->startSection('content'); ?>

<div id="notfound">
    <div class="notfound">
        <div class="notfound-404 pb-5">
            <h1>4<span>0</span>4</h1>
        </div>
        <p class="pt-5">
            <div class="pt-5">
                The page you are looking for might have been removed had its name changed or is temporarily unavailable.
            </div>
        </p>
        <a class="mt-5" href="<?php echo e(route('home')); ?>">home page</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tazerzit\resources\views/errors/404.blade.php ENDPATH**/ ?>