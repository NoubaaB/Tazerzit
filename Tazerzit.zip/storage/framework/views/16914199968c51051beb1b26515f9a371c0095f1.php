<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Tazerzit\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>